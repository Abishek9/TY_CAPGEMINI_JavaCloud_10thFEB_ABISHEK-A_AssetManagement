import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AssetsService } from '../assets.service';

@Component({
  selector: 'app-edit-assets',
  templateUrl: './edit-assets.component.html',
  styleUrls: ['./edit-assets.component.css']
})
export class EditAssetsComponent implements OnInit {

  productToUpdate

  constructor(private route: ActivatedRoute,
    private productService:  AssetsService,
    private router:Router) {
    this.route.queryParams.subscribe(data =>{
      this.productToUpdate=data;
      console.log(this.productToUpdate);
    })
   }

  ngOnInit() {
  }
  resetForm(form: NgForm){
    form.reset()
  }
  updateProduct(form: NgForm){
    this.productService.updateData(form.value).subscribe(response =>{
      console.log(response);
     
        form.reset();
        this.router.navigateByUrl('/current-assets');
      
    });
  }

}

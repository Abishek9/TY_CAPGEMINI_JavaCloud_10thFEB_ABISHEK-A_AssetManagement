import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AssetsService } from '../assets.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  message:string;
  constructor(private productService: AssetsService) { }

  ngOnInit() {
    
  }
  submitForm(form: NgForm){
    console.log(form.value)
  }
  resetForm(form: NgForm){
    form.reset()
  }
  postRequestData(form:NgForm ){
    this.productService.addUsers(form.value).subscribe(response  =>{
      console.log(response);
      form.reset();
      if(response.error === false){
        this.message = response.message;
        setTimeout(() =>{
          this.message = null;
          form.reset();
        },5000);
        }else{
          this.message = response.message;
        setTimeout(() =>{
          this.message = null;
        },5000);
        }
    })
  }
  
}

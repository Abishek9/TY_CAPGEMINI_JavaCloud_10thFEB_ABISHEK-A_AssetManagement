import { Component, OnInit } from '@angular/core';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';

export interface User{
  assetid: string;
  firstname : string;
  lastname:string;
  email:string;
  password:string;
  role:string;
}

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.css']
})
export class ViewUsersComponent implements OnInit {
  searchValue;
  searchBy="firstname";
  pageNo = 0;
  itemsPerPage = 2;
  totalItems;
  fieldName;
  message: string;
  users: User[]
  employee
  constructor(private productUsers: AssetsService,
    private router: Router) { 
      //  this.getUsers();
    }

  ngOnInit() {
    this.productUsers.getUser(this.pageNo,this.itemsPerPage,null).subscribe(data =>{
      console.log(data);
      this.users=data.content;
      this.totalItems=data.totalElements;
     
    });
  }

  getUsers(fieldName){
    this.productUsers.getUser(this.pageNo,this.itemsPerPage,this.fieldName).subscribe(data =>{
      console.log(data);
      this.users=data.content;
      this.totalItems=data.totalElements
    });
  }
  deleteUser(user){
    this.productUsers.deleteUser(user).subscribe(response =>{
      console.log(response);
      this.getUsers(this.fieldName);
    });
  }
  // getUsers(){
  //       this.productUsers.getUsers().subscribe(response =>{
  //         console.log(response);
  //          this.users=response;
  //       });
  //     }

  getNextPageItem(event){
    console.log(event);
     this.pageNo = event.pageIndex;
     this.itemsPerPage = event.pageSize;
     this.getUsers(this.fieldName);
  }

  getSortedData(){
    console.log(this.fieldName);
    this.getUsers(this.fieldName);
    
  }

  newUser(){
    this.router.navigate(['/register']);
  }
}

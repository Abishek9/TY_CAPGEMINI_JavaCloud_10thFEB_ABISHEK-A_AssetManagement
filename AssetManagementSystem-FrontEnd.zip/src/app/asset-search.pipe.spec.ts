import { AssetSearchPipe } from './asset-search.pipe';

describe('AssetSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new AssetSearchPipe();
    expect(pipe).toBeTruthy();
  });
});

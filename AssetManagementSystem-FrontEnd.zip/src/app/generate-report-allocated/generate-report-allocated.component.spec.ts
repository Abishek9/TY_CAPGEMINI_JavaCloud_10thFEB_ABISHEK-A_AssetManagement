import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateReportAllocatedComponent } from './generate-report-allocated.component';

describe('GenerateReportAllocatedComponent', () => {
  let component: GenerateReportAllocatedComponent;
  let fixture: ComponentFixture<GenerateReportAllocatedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateReportAllocatedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateReportAllocatedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';

export interface AllocatedAssets{
  employeeId: number;
  assetId : number;
  assetName:string;
  quantity:number;
  status:string;
}

@Component({
  selector: 'app-generate-report-allocated',
  templateUrl: './generate-report-allocated.component.html',
  styleUrls: ['./generate-report-allocated.component.css']
})



export class GenerateReportAllocatedComponent implements OnInit {

  allocatedassets:AllocatedAssets[];
  statusA = "Allocated";
  statusR = "Rejected";

  constructor(private productServices: AssetsService,
    private router: Router) {
        
     }

     ngOnInit() : void{
      this.productServices.getStatus(this.statusA).subscribe(response => {
        console.log(response);
       this.allocatedassets = response;
      })
  
   }
  
   changeStatusAllocated(){
    this.productServices.getStatus(this.statusA).subscribe(response => {
      console.log(response);
     this.allocatedassets = response;
   })
   }
  
   changeStatusUnallocated(){
    this.productServices.getStatus(this.statusR).subscribe(response => {
      console.log(response);
     this.allocatedassets = response;
   })
   }
  
  

   
    
}

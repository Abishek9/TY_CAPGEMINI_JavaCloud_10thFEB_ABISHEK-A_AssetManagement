import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'assetSearch'
})
export class AssetSearchPipe implements PipeTransform {

  transform(products: any[], searchValue: any, fieldName): any {
    if(!products){
      return [];
    }
    if(!searchValue){
      return products;
    }
    searchValue = searchValue.toLowerCase();

    return products.filter(product =>{
      if(isNaN(searchValue)){
      return product[fieldName].toLowerCase().includes(searchValue);
    }else{
      return product[fieldName].toString().toLowerCase().includes(searchValue);
    }
    });
    

  }

}

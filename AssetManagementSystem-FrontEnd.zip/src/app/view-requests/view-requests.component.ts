import { Component, OnInit } from '@angular/core';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';



interface RequestAsset {
  employeeId: number;
  requestId:number;
  assetId:number;
  assetName:string;
  quatity:number;
  status:number;
}

@Component({
  selector: 'app-view-requests',
  templateUrl: './view-requests.component.html',
  styleUrls: ['./view-requests.component.css']
})
export class ViewRequestsComponent implements OnInit {
//   pageNo = 0;
// itemsPerPage = 2;
// totalRequestAsset;
 products;
searchValue;
 searchBy="quantity";
pageNo = 0;
itemsPerPage = 2;
 totalItems;
fieldName;
message: string;
  requestAssets : RequestAsset[];

  constructor(private productServices: AssetsService,
    private router: Router) { 
    // this.getRequestProduct();
  }

  // getRequestProduct(){
  //   this.productServices.getRequestData().subscribe(response =>{
  //     console.log(response);
  //     this.requestAssets = response; 
  //   })
  // }
  getRequestProduct(fieldName){
    this.productServices.getRequestAsset(this.pageNo,this.itemsPerPage,this.fieldName).subscribe(data =>{
      console.log(data);
      this.requestAssets=data.content;
      this.totalItems=data.totalElements
    });
  }
  ngOnInit(): void {
    this.productServices.getRequestAsset(this.pageNo,this.itemsPerPage,null).subscribe(data =>{
      console.log(data);
      this.requestAssets=data.content;
      this.totalItems=data.totalElements;
    
    
    });
  }
  updateStatus(asset){
    this.router.navigate(['/update-status'],{queryParams:asset});
  }

  getNextPageItems(event){
    console.log(event);
     this.pageNo = event.pageIndex;
     this.itemsPerPage = event.pageSize;
     this.getRequestProduct(this.fieldName);
  }

  getSortedData(){
    console.log(this.fieldName);
     this.getRequestProduct(this.fieldName);
  }
  

}

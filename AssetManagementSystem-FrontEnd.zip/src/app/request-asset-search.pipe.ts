import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'requestAssetSearch'
})
export class RequestAssetSearchPipe implements PipeTransform {

  transform(requestAssets: any[], searchValue: any, fieldName): any {
    if(!requestAssets){
      return[];
    }
    if(!searchValue){
      return requestAssets;
    }
    searchValue = searchValue.toLowerCase();
     return requestAssets.filter(requestAsset =>{
       if(isNaN(searchValue)){
        return requestAsset[fieldName].toLowerCase().includes(searchValue);
       }else{
        return requestAsset[fieldName].toString().toLowerCase().includes(searchValue);

       }
      });
    return null;
  }

}

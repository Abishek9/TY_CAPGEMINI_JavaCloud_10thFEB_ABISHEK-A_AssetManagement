import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  constructor(private userService: AssetsService,private router: Router) { }

  message: string;
  ngOnInit() {
  }
 

  login(form : NgForm){
    console.log(form.value);
    this.userService.loginUser(form.value).subscribe(response =>{
      console.log(response);
      if(response.error){
        this.message = response.message;
        setTimeout(()=>{
          this.message = null;
        
        },5000)
      }else{
        localStorage.setItem('userData',JSON.stringify(response)) ;
        if(response.data.role === 'ROLE_ADMIN'){
          this.router.navigateByUrl('/current-assets');
        }else if(response.data.role === 'ROLE_USER'){
          this.router.navigateByUrl('/request');
        }
      }
    })
  }



}

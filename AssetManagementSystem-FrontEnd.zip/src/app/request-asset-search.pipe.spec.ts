import { RequestAssetSearchPipe } from './request-asset-search.pipe';

describe('RequestAssetSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new RequestAssetSearchPipe();
    expect(pipe).toBeTruthy();
  });
});

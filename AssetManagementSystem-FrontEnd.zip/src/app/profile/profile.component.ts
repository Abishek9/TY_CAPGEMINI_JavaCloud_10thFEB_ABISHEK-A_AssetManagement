import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';

export interface Profile{
  userId:number;
  firstName:string;
  lastName:string;
  email:string;
  password:string;
  role:string;
}
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  email;
  profiles: Profile[];
  constructor(private profileService: AssetsService,
    private router: Router) {

   }

  ngOnInit() {
    const registerData = JSON.parse(localStorage.getItem('userData'));
      this.email = registerData.data.email;

    this.profileService.getprofile(this.email).subscribe(response =>{
      console.log(response);
      this.profiles = response.data;
      console.log(this.profiles)
    })
  }

  updateprofile(user){
    this.router.navigate(['/edit-profile'],{queryParams:user})
  }

}

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';

export interface Product{
  assetId: number;
  title : string;
  category:string;
  quantity:number;
  price:number;
  totalprice:number;
  details:string;
}

@Component({
  selector: 'app-current-assets',
  templateUrl: './current-assets.component.html',
  styleUrls: ['./current-assets.component.css']
})
export class CurrentAssetsComponent implements OnInit {

  searchValue;
  searchBy="title";
  pageNo = 0;
  itemsPerPage = 2;
  totalItems;
  fieldName;
  message: string;
  products: Product[];

  constructor(private productService: AssetsService,
    private router: Router) {
    this.getProducts(null);
   }
//  getProducts(){
//     this.productService.getData().subscribe(response =>{
//       console.log(response);
//       this.products=response;
//     });
//   }
getProducts(fieldName){
  this.productService.getAsset(this.pageNo,this.itemsPerPage,fieldName).subscribe(data =>{
    console.log(data);
    this.products=data.content;
    this.totalItems=data.totalElements
  });
}

generateReport(){
  this.router.navigate(['/generate-report-allocated']);
}

  deleteProduct(product){
    this.productService.deleteData(product).subscribe(response =>{
      console.log(response);
      this.getProducts(null);
      // if(response.error === false){
      //   this.getProducts(null);
      //   this.message=response.message;
      //   setTimeout(() => {
      //     this.message = null;
      //   },5000);
      // }
    });
  }

  updateProduct(product){
    this.router.navigate(['/edit-assets'],{queryParams:product})
  }
  ngOnInit():void {
    this.productService.getAsset(this.pageNo,this.itemsPerPage,null).subscribe(data =>{
      console.log(data);
      this.products=data.content;
      this.totalItems=data.totalElements
    });
  }
  getNextPageItem(event){
    console.log(event);
    this.pageNo = event.pageIndex;
    this.itemsPerPage = event.pageSize;
    this.getProducts(this.fieldName);
  }

  getSortedData(){
    console.log(this.fieldName);
    this.getProducts(this.fieldName);
  }
  }



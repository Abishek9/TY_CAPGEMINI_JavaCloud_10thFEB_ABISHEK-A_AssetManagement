import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule} from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { AddAssetsComponent } from './add-assets/add-assets.component';
import { CurrentAssetsComponent } from './current-assets/current-assets.component';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RequestComponent } from './request/request.component';
import { ConfirmEqualValidatorDirective } from './register/confirm-equal-validator.directive';
import { LogoutComponent } from './logout/logout.component';
import { AssetComponent } from './asset/asset.component';
import { ViewStatusComponent } from './view-status/view-status.component';
import { ViewRequestsComponent } from './view-requests/view-requests.component';
import { ProfileComponent } from './profile/profile.component';
import { EditAssetsComponent } from './edit-assets/edit-assets.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 import {MatPaginatorModule} from '@angular/material/paginator';
import { AssetSearchPipe } from './asset-search.pipe';
import { UpdateStatusComponent } from './update-status/update-status.component';
import { RequestAssetSearchPipe } from './request-asset-search.pipe';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { ViewUsersComponent } from './view-users/view-users.component';
import { UserSearchPipe } from './user-search.pipe';
import { GenerateReportAllocatedComponent } from './generate-report-allocated/generate-report-allocated.component';
import { AuthGuard } from './welcome/auth.guard';
import { RequestInterceptor } from './request.interceptor';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    RegisterComponent,
    AddAssetsComponent,
    CurrentAssetsComponent,
    HeaderComponent,
    RequestComponent,
    ConfirmEqualValidatorDirective,
    LogoutComponent,
    AssetComponent,
    ViewStatusComponent,
    ViewRequestsComponent,
    ProfileComponent,
    EditAssetsComponent,
    AssetSearchPipe,
    UpdateStatusComponent,
    RequestAssetSearchPipe,
    EditProfileComponent,
    ViewUsersComponent,
    UserSearchPipe,
    GenerateReportAllocatedComponent,
    PageNotFoundComponent,
  ],
  imports: [
    BrowserModule,
     MatPaginatorModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'welcome', component:WelcomeComponent},
      {path:'register', component:RegisterComponent},
      {path:'current-assets', component:CurrentAssetsComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'add-assets', component:AddAssetsComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'request', component:RequestComponent, data:{role:['ROLE_USER']},canActivate:[AuthGuard]},
      {path:'logout', component:LogoutComponent},
      {path:'',redirectTo:'/asset',pathMatch:'full'},
      {path:'asset',component:AssetComponent},
      {path:'view-status',component:ViewStatusComponent, data:{role:['ROLE_USER']},canActivate:[AuthGuard]},
      {path:'view-requests',component:ViewRequestsComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'profile',component:ProfileComponent, data:{role:['ROLE_USER']},canActivate:[AuthGuard]},
      {path:'edit-assets',component:EditAssetsComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'update-status',component:UpdateStatusComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'edit-profile',component:EditProfileComponent, data:{role:['ROLE_USER']},canActivate:[AuthGuard]},
      {path:'view-users',component:ViewUsersComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'generate-report-allocated',component:GenerateReportAllocatedComponent, data:{role:['ROLE_ADMIN']},canActivate:[AuthGuard]},
      {path:'**',component:PageNotFoundComponent}
    ]),
    BrowserAnimationsModule
  ],
  providers: [{
    provide:HTTP_INTERCEPTORS,
    useClass:RequestInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AssetsService {

  constructor(private http:HttpClient, private router: Router) { }

  myURL = 'http://localhost:8080/api'
  myURLs = 'http://localhost:8080/api/assets'
  myURL2='http://localhost:8080/api/requestassets'
  myURL3='http://localhost:8080/api/users'

  
  postData(product){
    return this.http.post<any>('http://localhost:8080/api/addassets',product);
  }
  getData(){
    return this.http.get<any>('http://localhost:8080/api/assets');
  }
  deleteData(product){
    return this.http.delete<any>(`${this.myURL}/assets/${product.assetId}`);
  }

  updateData(product){
    return this.http.put<any>('http://localhost:8080/api/assets',product);
  }
  getAsset(pageNo,itemsPerPage,sortBy){
    if(!sortBy){
    return this.http.get<{content: any[], totalElements: number}>(`${this.myURLs}/${pageNo}/${itemsPerPage}`);
  }else{
    return this.http.get<{content: any[], totalElements: number}>(`${this.myURLs}/${pageNo}/${itemsPerPage}/${sortBy}`);
  }
  }
  postRequestData(product){
    
    return this.http.post<any>('http://localhost:8080/api/sendrequestassets',product
    );
  }
  getRequestData(){
    return this.http.get<any>('http://localhost:8080/api/getallrequestassets');
  }
  updateRequestData(product){
    return this.http.put<any>('http://localhost:8080/api/updaterequestassets',product);
  }

  getRequestAsset(pageNo,itemsPerPage,sortBy){
    if(!sortBy){
    return this.http.get<{content: any[], totalElements: number}>(`${this.myURL2}/${pageNo}/${itemsPerPage}`);
  }else{
    return this.http.get<{content: any[], totalElements: number}>(`${this.myURL2}/${pageNo}/${itemsPerPage}/${sortBy}`);

  }
}
  getprofile(email){
    return this.http.get<any>(`${this.myURL}/users/${email}`);
  }
  updateprofile(user){
    return this.http.put<any>('http://localhost:8080/api/updateUser',user);
  }
  getUsers(){
    return this.http.get<any>('http://localhost:8080/api/users');
  }

  addUsers(user){
    return this.http.post<any>('http://localhost:8080/api/addusers',user);
  }

  getUser(pageNo,itemsPerPage,sortBy){
    if(!sortBy){
    return this.http.get<{content: any[], totalElements: number}>(`${this.myURL3}/${pageNo}/${itemsPerPage}`);
    }else{
      return this.http.get<{content: any[], totalElements: number}>(`${this.myURL3}/${pageNo}/${itemsPerPage}/${sortBy}`);

    }
  }

  emailData(request){
    return this.http.post<any>(`${this.myURL}/addrequest/${request.email}`,request);
  }

  profileData(email){
    return this.http.get<any>(`${this.myURL}/getS/${email}`);
  }
  updateEmail(request){
    return this.http.put<any>(`${this.myURL}/updaterequest/${request.email}`,request);
  }

  getStatus(status){
    return this.http.get<any>(`${this.myURL}/get/${status}`);
  }

  deleteUser(user){
     return this.http.delete<any>(`${this.myURL}/deleteusers/${user.email}`);
  }

  loginUser(userCredentials){
    return this.http.post<any>(`${this.myURL}/login`,userCredentials);
  }

  isUser(): boolean {
    const userData  = JSON.parse(localStorage.getItem('userData'));
    if(userData &&userData.data.role === 'ROLE_USER'){
      return true;
    }else{
      return false;
    }
  }

  isAdmin(): boolean {
    const userData  = JSON.parse(localStorage.getItem('userData'));
    if(userData &&userData.data.role === 'ROLE_ADMIN'){
      return true;
    }else{
      return false;
    }
  }

  isLogged(): boolean {
    const userData  = JSON.parse(localStorage.getItem('userData'));
    if(userData){
      return true;
    }else{
      return false;
    }
  }

  logout(){
    localStorage.clear();
    this.router.navigateByUrl('/welcome')
  }

}

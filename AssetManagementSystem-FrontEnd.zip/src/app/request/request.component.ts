import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AssetsService } from '../assets.service';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {

  message: string;
  defaultValue = "pending";
  emailHard;

  constructor(private productService: AssetsService) { }

  ngOnInit() {
    const registerData = JSON.parse(localStorage.getItem('userData'));
    this.emailHard = registerData.data.email;
  }
  reset(form: NgForm){
    form.reset()
  }

postRequestData(form:NgForm ){
  this.productService.emailData(form.value).subscribe(response  =>{
    console.log(response);
    if(response.error === false){
      this.message = response.message;
      setTimeout(() =>{
        this.message = null;
      },5000);
    }
    form.reset();
  })
}

}

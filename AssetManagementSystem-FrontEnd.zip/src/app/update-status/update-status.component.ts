import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AssetsService } from '../assets.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-status',
  templateUrl: './update-status.component.html',
  styleUrls: ['./update-status.component.css']
})
export class UpdateStatusComponent implements OnInit {

  emailH;
  productToUpdate;
  constructor(private route: ActivatedRoute,
    private productService :AssetsService,
    private router: Router) {
    this.route.queryParams.subscribe(data =>{
      this.productToUpdate=data;
      console.log(this.productToUpdate)
    });
   }

   updateRequestProduct(form: NgForm){
     this.productService.updateEmail(form.value).subscribe(response =>{
      console.log(response);
      if(response.error === false){
        form.reset();
        this.router.navigateByUrl('/view-requests');
      }
     })
   }
  ngOnInit() {
    const registerData = JSON.parse(localStorage.getItem('userData'));
    console.log(registerData);
    this.emailH = registerData.data.email;
  }

}

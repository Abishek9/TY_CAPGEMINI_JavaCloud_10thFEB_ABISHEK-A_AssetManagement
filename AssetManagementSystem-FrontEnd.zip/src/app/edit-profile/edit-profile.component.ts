import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AssetsService } from '../assets.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  profileToUpdate
  defaultValue1:"ROLE_USER"

  constructor(private route: ActivatedRoute,
    private profileService:  AssetsService,
    private router:Router) {
    this.route.queryParams.subscribe(data =>{
      this.profileToUpdate=data;
      console.log(this.profileToUpdate);
    })
   }

  ngOnInit() {
  }

  updateProfile(form: NgForm){
    this.profileService.updateprofile(form.value).subscribe(response =>{
      console.log(response);
      // if(response.error === false){
      //   form.reset();
      //   this.router.navigateByUrl('/profile');
      // }
     
        
      
    });
  }
}

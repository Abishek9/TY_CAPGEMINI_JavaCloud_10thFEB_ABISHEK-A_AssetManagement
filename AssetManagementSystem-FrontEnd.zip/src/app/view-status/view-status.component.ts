import { Component, OnInit } from '@angular/core';
import { AssetsService } from '../assets.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-view-status',
  templateUrl: './view-status.component.html',
  styleUrls: ['./view-status.component.css']
})
export class ViewStatusComponent implements OnInit {
  email;
requestAssets ;
demo;
  constructor(private productServices: AssetsService,
    private router: Router) { 
   
  }


  ngOnInit() {
    const registerData = JSON.parse(localStorage.getItem('userData'));
    this.email = registerData.data.email;
    this.productServices.profileData(this.email).subscribe(response =>{
      console.log(response);
      this.requestAssets = response.data.requestAsset;
      this.demo=response.data.requestAsset.emailid;
      console.log(this.demo);
    })
  }

}
